﻿import { test, expect } from '@playwright/test';
import { login } from './helpers/auth';

test.describe('Section 15 — Mobile', () => {
  test.beforeEach(async ({ page }) =>
    login(page, process.env.ALICE_EMAIL!, process.env.ALICE_PASSWORD!));

  test('15.1 bottom nav visible', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('[data-testid="mobile-nav"]')).toBeVisible();
  });

  test('15.2 feed is single column', async ({ page }) => {
    await page.goto('/');
    const cols = await page.locator('[data-testid="feed"]').evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns.split(' ').length
    );
    expect(cols).toBe(1);
  });

  test('15.3 library sidebar hidden', async ({ page }) => {
    await page.goto('/artists');
    await expect(page.locator('[data-testid="library-sidebar"]')).toBeHidden();
  });

  test('15.6 dropdown does not overflow', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: /avatar|account/i }).first().click();
    const box = await page.getByRole('menu').boundingBox();
    const vw = page.viewportSize()!.width;
    expect(box!.x).toBeGreaterThanOrEqual(0);
    expect(box!.x + box!.width).toBeLessThanOrEqual(vw + 1);
  });
});
